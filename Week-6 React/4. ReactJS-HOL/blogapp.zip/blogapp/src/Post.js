
import React from 'react';

function Post(props) {
  return (
    <div style={{ border: '1px solid black', marginBottom: '10px', padding: '10px' }}>
      <h2>{props.title}</h2>
      <p>{props.body}</p>
    </div>
  );
}

export default Post;
