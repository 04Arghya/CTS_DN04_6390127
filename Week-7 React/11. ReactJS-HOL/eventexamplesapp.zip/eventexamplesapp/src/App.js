import React, { useState } from 'react';

function App() {
  const [count, setCount] = useState(0);
  const [rupees, setRupees] = useState('');
  const [euros, setEuros] = useState('');

  // Counter functions
  const sayHello = () => {
    console.log("Hello, this is an increment action.");
  };

  const increment = () => {
    setCount(prev => prev + 1);
    sayHello();
  };

  const decrement = () => {
    setCount(prev => prev - 1);
  };

  // Say Welcome function
  const sayMessage = (msg) => {
    alert(msg);
  };

  // Synthetic event function
  const handlePress = (e) => {
    e.preventDefault(); // using React's SyntheticEvent
    alert("I was clicked");
  };

  // Currency converter handler
  const handleSubmit = () => {
    if (rupees && !isNaN(rupees)) {
      const euroValue = parseFloat(rupees) / 90; // static conversion rate
      setEuros(euroValue.toFixed(2));
    } else {
      alert("Please enter a valid number");
    }
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial' }}>
      <h1>React Event Handling Lab</h1>

      {/* Counter */}
      <h2>Counter: {count}</h2>
      <button onClick={increment}>Increment</button>
      <button onClick={decrement} style={{ marginLeft: '10px' }}>Decrement</button>

      <hr />

      {/* Say Welcome */}
      <h2>Say Welcome</h2>
      <button onClick={() => sayMessage("Welcome")}>Say Welcome</button>

      <hr />

      {/* Synthetic Event */}
      <h2>Synthetic Event</h2>
      <button onClick={handlePress}>OnPress</button>

      <hr />

      {/* Currency Converter */}
      <h2>Currency Converter (INR to Euro)</h2>
      <input
        type="number"
        value={rupees}
        onChange={(e) => setRupees(e.target.value)}
        placeholder="Enter amount in INR"
      />
      <button onClick={handleSubmit} style={{ marginLeft: '10px' }}>Convert</button>
      {euros && <p>Equivalent in Euros: €{euros}</p>}
    </div>
  );
}

export default App;
