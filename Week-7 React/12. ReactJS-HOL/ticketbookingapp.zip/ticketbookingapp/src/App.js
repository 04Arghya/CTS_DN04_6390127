import React, { useState } from 'react';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const GuestPage = () => (
    <div>
      <h2>Guest Page</h2>
      <p>You can browse available flights below:</p>
      <ul>
        <li>Flight 1: Delhi to London</li>
        <li>Flight 2: Mumbai to Dubai</li>
      </ul>
    </div>
  );

  const UserPage = () => (
    <div>
      <h2>User Page</h2>
      <p>You can now book your flight tickets.</p>
      <ul>
        <li>Flight 1: Delhi to London</li>
        <li>Flight 2: Mumbai to Dubai</li>
      </ul>
      <button>Book Ticket</button>
    </div>
  );

  // Element variable for rendering pages
  let pageContent;
  if (isLoggedIn) {
    pageContent = <UserPage />;
  } else {
    pageContent = <GuestPage />;
  }

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial' }}>
      <h1>Ticket Booking App</h1>
      
      {isLoggedIn ? (
        <button onClick={() => setIsLoggedIn(false)}>Logout</button>
      ) : (
        <button onClick={() => setIsLoggedIn(true)}>Login</button>
      )}

      <hr />

      {/* Conditional Rendering using element variable */}
      {pageContent}
    </div>
  );
}

export default App;
