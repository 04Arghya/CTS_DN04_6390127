import React from 'react';

const ListOfPlayers = () => {
  const players = [
    { name: "Virat", score: 95 },
    { name: "Rohit", score: 88 },
    { name: "Dhoni", score: 67 },
    { name: "Hardik", score: 45 },
    { name: "KL Rahul", score: 77 },
    { name: "Bumrah", score: 50 },
    { name: "Shami", score: 65 },
    { name: "Jadeja", score: 80 },
    { name: "Ashwin", score: 40 },
    { name: "Gill", score: 90 },
    { name: "Iyer", score: 73 }
  ];

  const filtered = players.filter(player => player.score < 70);

  return (
    <div>
      <h2>All Players</h2>
      <ul>
        {players.map((player, i) => (
          <li key={i}>{player.name} - {player.score}</li>
        ))}
      </ul>

      <h3>Players with score below 70</h3>
      <ul>
        {filtered.map((player, i) => (
          <li key={i}>{player.name} - {player.score}</li>
        ))}
      </ul>
    </div>
  );
};

export default ListOfPlayers;
