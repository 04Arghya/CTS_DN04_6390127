import React from 'react';

const IndianPlayers = () => {
  const T20players = ["Virat", "Rohit", "Hardik", "Rahul"];
  const RanjiPlayers = ["Pujara", "Rahane", "Ishant", "Saha"];

  const allPlayers = [...T20players, ...RanjiPlayers]; // merge arrays

  const oddPlayers = allPlayers.filter((_, i) => i % 2 !== 0);
  const evenPlayers = allPlayers.filter((_, i) => i % 2 === 0);

  return (
    <div>
      <h2>Odd Team Players</h2>
      <ul>
        {oddPlayers.map((name, i) => <li key={i}>{name}</li>)}
      </ul>

      <h2>Even Team Players</h2>
      <ul>
        {evenPlayers.map((name, i) => <li key={i}>{name}</li>)}
      </ul>
    </div>
  );
};

export default IndianPlayers;
