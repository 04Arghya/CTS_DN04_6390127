import React, { useState } from 'react';
import BookDetails from './components/BookDetails';
import BlogDetails from './components/BlogDetails';
import CourseDetails from './components/CourseDetails';


function App() {
  const [selected, setSelected] = useState('');

  // Switch-style conditional rendering
  const renderComponent = () => {
    switch (selected) {
      case 'book':
        return <BookDetails />;
      case 'blog':
        return <BlogDetails />;
      case 'course':
        return <CourseDetails />;
      default:
        return <p>Please select a section to display.</p>;
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h1>Blogger App</h1>
      
      {/* if/else rendering using buttons */}
      <button onClick={() => setSelected('book')}>Show Book Details</button>
      <button onClick={() => setSelected('blog')}>Show Blog Details</button>
      <button onClick={() => setSelected('course')}>Show Course Details</button>

      <hr />

      {/* Render selected component */}
      {renderComponent()}

      {/* && rendering */}
      {selected === '' && <p>No component selected yet.</p>}
    </div>
  );
}

export default App;
