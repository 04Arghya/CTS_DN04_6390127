import React from 'react';

function BlogDetails() {
  const blogs = [
    { id: 1, title: "Understanding useState" },
    { id: 2, title: "JSX vs HTML" },
    { id: 3, title: "React Performance Tips" }
  ];

  return (
    <div>
      <h2>Blog Details</h2>
      <ul>
        {blogs.map(blog => (
          <li key={blog.id}>{blog.title}</li> // using unique keys
        ))}
      </ul>
    </div>
  );
}

export default BlogDetails;
