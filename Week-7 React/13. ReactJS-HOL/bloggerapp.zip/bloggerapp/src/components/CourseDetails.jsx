import React from 'react';

function CourseDetails() {
  const show = true;

  return (
    <div>
      <h2>Course Details</h2>
      {/* Ternary rendering */}
      {show ? (
        <p>Course is currently open for enrollment.</p>
      ) : (
        <p>Enrollment is closed.</p>
      )}
    </div>
  );
}

export default CourseDetails;
