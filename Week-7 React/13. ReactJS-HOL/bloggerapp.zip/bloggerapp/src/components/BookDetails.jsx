import React from 'react';

function BookDetails() {
  const books = ["React Explained", "Mastering JSX", "Hooks in Depth"];
  
  return (
    <div>
      <h2>Book Details</h2>
      <ul>
        {books.map((book, index) => (
          <li key={index}>{book}</li> // using keys
        ))}
      </ul>
    </div>
  );
}

export default BookDetails;
