import React from 'react';

function App() {
  // Single office object
  const office = {
    name: "Orgoz Co-working Space",
    rent: 55000,
    address: "Ballygunge, Kolkata",
    image: "imag4.jpeg"
  };

  // List of office spaces
  const offices = [
    { name: "Startup Hub", rent: 45000, address: "Salt Lake", image: "image.png" },
    { name: "TechNest", rent: 60000, address: "Sector V", image: "img3.jpg" },
    { name: "HiveSpace", rent: 75000, address: "New Town", image: "img 2.jpg" },
    { name: "Cowork Junction", rent: 58000, address: "Park Street", image: "images.jpeg" }
  ];

  // Inline style function
  const getRentStyle = (rent) => {
    return {
      color: rent < 60000 ? 'red' : 'green',
      fontWeight: 'bold'
    };
  };

  return (
    <div className="App">
      {/* Heading */}
      <h1>Office Space Rental</h1>

      {/* Single office details */}
      <h2>{office.name}</h2>
      <img src={office.image} alt="Office" width="300" />
      <p><strong>Rent:</strong> <span style={getRentStyle(office.rent)}>{office.rent}</span></p>
      <p><strong>Address:</strong> {office.address}</p>

      {/* List of office spaces */}
      <h2>Available Spaces</h2>
      <ul>
        {offices.map((o, i) => (
          <li key={i}>
            <img src={o.image} alt={`Office ${i}`} width="150" />
            <p><strong>{o.name}</strong></p>
            <p>Rent: <span style={getRentStyle(o.rent)}>{o.rent}</span></p>
            <p>Address: {o.address}</p>
            <hr />
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
